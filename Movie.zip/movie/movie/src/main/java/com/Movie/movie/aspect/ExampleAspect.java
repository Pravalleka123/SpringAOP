package com.Movie.movie.aspect;

import com.Movie.movie.model.Movie;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component

public class ExampleAspect
{
//    @Around("@annotation(LogExecutionTime)")
    @AfterReturning(value = "@annotation(DeliveredBy)",returning = "result")
    public void deliveredby(Object result) throws Throwable {

        Movie movieproceed = (Movie)result;
        movieproceed.setDeliveredby("saritha");

    }
//    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable
//    {
//        long start = System.currentTimeMillis();
//
//        Object proceed = joinPoint.proceed();
//        System.out.println("proceed"+proceed);
//
//        long executionTime = System.currentTimeMillis() - start;
//        Movie movieproceed=(Movie)proceed;
//        movieproceed.setTimetaken(executionTime);

//        System.out.println(joinPoint.getSignature() + " executed in " + executionTime + "ms");
//        return proceed;
}
