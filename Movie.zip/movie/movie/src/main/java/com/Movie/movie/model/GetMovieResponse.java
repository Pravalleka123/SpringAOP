package com.Movie.movie.model;

import java.util.ArrayList;
import java.util.List;

public class GetMovieResponse
{
    String actor;
    List<MovieResponse> movieResponseList;

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public List<MovieResponse> getMovieResponseList() {
        return movieResponseList;
    }

    public void setMovieResponseList(List<MovieResponse> movieResponseList) {
        this.movieResponseList = movieResponseList;
    }
}
