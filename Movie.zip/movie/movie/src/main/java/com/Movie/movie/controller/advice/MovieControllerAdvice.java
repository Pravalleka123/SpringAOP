package com.Movie.movie.controller.advice;

import com.Movie.movie.model.MovieError;
import com.Movie.movie.validator.MovieException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice(basePackages="com.Movie.movie.controller")
public class MovieControllerAdvice
{
    @ExceptionHandler(MovieException.class)
    public ResponseEntity<Object> handleCustomException(MovieException movieException)
    {
        MovieError movieError=new MovieError();
        movieError.setErrormessage(movieException.getMessage());
        movieError.setErrorcode(movieException.getErrorcode());
        ResponseEntity responseEntity=new ResponseEntity(movieError, HttpStatus.BAD_REQUEST);
        return responseEntity;

    }
}
