package com.Movie.movie.service;

import com.Movie.movie.aspect.DeliveredBy;
import com.Movie.movie.aspect.LogExecutionTime;
import com.Movie.movie.model.Movie;
import com.Movie.movie.repository.MovieRepository;
import com.Movie.movie.validator.MovieValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;


@Service
public class MovieService
{
    @Autowired
    MovieRepository movieRepository;
    @Autowired
    MovieValidator movieValidator;
    public Movie movie()
    {
    return movieRepository.getmovie();
    }

    @LogExecutionTime
    @DeliveredBy
    public Movie addmovie(Movie movie)
    {
//        Random rand = new Random();
        movieValidator.reqValidation(movie);
        int rand_id = (int)(Math.random()*10000000);
        movie.setId(rand_id);
        return movieRepository.addmovie(movie);
    }
    public List<Movie> getMovielist()
    {
        return movieRepository.getMovielist();
    }


}
